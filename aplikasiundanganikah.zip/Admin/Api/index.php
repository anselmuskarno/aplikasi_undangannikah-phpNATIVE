<table width=100% border=0>
<tr height=80>
<td><iframe name=sinkron scrolling=no frameborder=0 width=100% height=50 src=autosinkron2.php></iframe></td>
</tr>
</table>

<table width=100% border=0>
<tr>
<td width=150 valign=top>
<input type=button onclick="window.open('upload.php','frm')" value="Upload Excel">
<br><br>
<input type=button onclick="window.open('belum_dikirim.php','frm')" value="Belum Dikirim">
<br><br>
<input type=button onclick="window.open('antri_dikirim.php','frm')" value="Menunggu Antrian">
<br><br>
<input type=button onclick="window.open('sudah_dikirim.php','frm')" value="Sudah Terkirim">
</td>
<td>
<iframe width=100% height=2000 src='sudah_dikirim.php' frameborder=0 name=frm></iframe>
</td>
</tr>
</table>