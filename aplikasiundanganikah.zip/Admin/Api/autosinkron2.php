<?php
	require_once "koneksi.php";
?>
<head>
  <meta http-equiv="refresh" content="1;URL=autosinkron.php?time=<?php echo date('YmdHis');?>">
</head>
<p align=right><br>Proses sinkronisasi ke server...</p>